var structMagellan_1_1lssdp__packet =
[
    [ "cache_control", "structMagellan_1_1lssdp__packet.html#a2392c9bed747316005cf4928301b7c7a", null ],
    [ "date", "structMagellan_1_1lssdp__packet.html#a84bfd38246adec453df68bfbf4ee2899", null ],
    [ "device_type", "structMagellan_1_1lssdp__packet.html#ac54d810e9447d2c2391f7924e4d564fd", null ],
    [ "location", "structMagellan_1_1lssdp__packet.html#ad7def03109c85f2183026ce984f3f73c", null ],
    [ "method", "structMagellan_1_1lssdp__packet.html#ad96d78676434b4e3595d1b4442e8c03f", null ],
    [ "received_ts", "structMagellan_1_1lssdp__packet.html#a7f1111d12403703e0d3e16dcd3f7bd94", null ],
    [ "server", "structMagellan_1_1lssdp__packet.html#ac075b23c4c1431962653f481fa305a32", null ],
    [ "sm_id", "structMagellan_1_1lssdp__packet.html#a57828901c9ca4d25710ba0bd5e73569b", null ],
    [ "st", "structMagellan_1_1lssdp__packet.html#a68a5f8e6d5a12fd15e4f9ccda537e644", null ],
    [ "usn", "structMagellan_1_1lssdp__packet.html#af05c6932bc8457716b44d7afc8157d05", null ],
    [ "x_magellan_cv", "structMagellan_1_1lssdp__packet.html#a1d3a8a9133c4e0aed008398f421e611c", null ],
    [ "x_magellan_id", "structMagellan_1_1lssdp__packet.html#a6c43945fda39a77794b9677d13a9aa3d", null ]
];