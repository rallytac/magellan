var classMagellan_1_1AppDiscoverer =
[
    [ "AppDiscoverer", "classMagellan_1_1AppDiscoverer.html#a46d3ba78e62980ae4ecc99b29139c83d", null ],
    [ "~AppDiscoverer", "classMagellan_1_1AppDiscoverer.html#abb994afb8ff85d918fb4e34d9b431c60", null ],
    [ "configure", "classMagellan_1_1AppDiscoverer.html#a4723996d2f03902608bf33f193262854", null ],
    [ "pause", "classMagellan_1_1AppDiscoverer.html#ae1faa805879d394cd34fd27b124b4376", null ],
    [ "resume", "classMagellan_1_1AppDiscoverer.html#ad42c1b50dfc97ee502b9c3067b3a255b", null ],
    [ "start", "classMagellan_1_1AppDiscoverer.html#ac41d20c9439f157c67aa014b81c674ab", null ],
    [ "stop", "classMagellan_1_1AppDiscoverer.html#a96d50102bee764a38e3e6b75ef636680", null ]
];