var classMagellan_1_1DataModel_1_1Presence =
[
    [ "Presence", "classMagellan_1_1DataModel_1_1Presence.html#a56b8f0e125007401111e64a98162c4c6", null ],
    [ "clear", "classMagellan_1_1DataModel_1_1Presence.html#a98ccfdd08b8523c3720103f9fb58ec0d", null ],
    [ "matches", "classMagellan_1_1DataModel_1_1Presence.html#a959910737c7589064293c6cc15bfd2ba", null ],
    [ "forceOnAudioTransmit", "classMagellan_1_1DataModel_1_1Presence.html#af3bd752ae8dac902c50b9a2fa30a126e", null ],
    [ "format", "classMagellan_1_1DataModel_1_1Presence.html#a3fbe398c5210be43340a01386eb0ef63", null ],
    [ "intervalSecs", "classMagellan_1_1DataModel_1_1Presence.html#af6f91474e27975aa055544b5f145f737", null ]
];