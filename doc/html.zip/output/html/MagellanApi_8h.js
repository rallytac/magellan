var MagellanApi_8h =
[
    [ "magellanBeginDiscovery", "MagellanApi_8h.html#a005b91994aa0c659b774db6381ef4730", null ],
    [ "magellanEndDiscovery", "MagellanApi_8h.html#a5b709ba6628497dae95191a78d650c59", null ],
    [ "magellanInitialize", "MagellanApi_8h.html#a5cb6434bb0ca5dd36558d9ebb4ceb874", null ],
    [ "magellanLogMessage", "MagellanApi_8h.html#a895c21189d0318db2cdb74fbabb5f052", null ],
    [ "magellanPauseDiscovery", "MagellanApi_8h.html#a29228e3a54d03e2a438789bbd832094c", null ],
    [ "magellanResumeDiscovery", "MagellanApi_8h.html#a19101f1726468ab9c727b5c8a3d15d0e", null ],
    [ "magellanSetLoggingHook", "MagellanApi_8h.html#a3df0c637708ef7daed1d510d2b139e6b", null ],
    [ "magellanSetLoggingLevel", "MagellanApi_8h.html#a5227a1ec7ca9d61ef6d192cd2d53d172", null ],
    [ "magellanSetTalkgroupCallbacks", "MagellanApi_8h.html#aea463cb1142b80a37f83715f7a1ee946", null ],
    [ "magellanShutdown", "MagellanApi_8h.html#a4855c480145d6e4ba3c7ba7bf7226526", null ]
];