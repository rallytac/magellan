var annotated_dup =
[
    [ "Magellan", null, [
      [ "Core", null, [
        [ "DeviceConfigurationDownloadCtx", "classMagellan_1_1Core_1_1DeviceConfigurationDownloadCtx.html", "classMagellan_1_1Core_1_1DeviceConfigurationDownloadCtx" ],
        [ "DeviceTracker", "classMagellan_1_1Core_1_1DeviceTracker.html", "classMagellan_1_1Core_1_1DeviceTracker" ]
      ] ],
      [ "DataModel", null, [
        [ "DeviceConfiguration", "classMagellan_1_1DataModel_1_1DeviceConfiguration.html", "classMagellan_1_1DataModel_1_1DeviceConfiguration" ],
        [ "DiscoveredDevice", "classMagellan_1_1DataModel_1_1DiscoveredDevice.html", "classMagellan_1_1DataModel_1_1DiscoveredDevice" ],
        [ "JsonObjectBase", "classMagellan_1_1DataModel_1_1JsonObjectBase.html", "classMagellan_1_1DataModel_1_1JsonObjectBase" ],
        [ "MagellanConfiguration", "classMagellan_1_1DataModel_1_1MagellanConfiguration.html", "classMagellan_1_1DataModel_1_1MagellanConfiguration" ],
        [ "Mdns", "classMagellan_1_1DataModel_1_1Mdns.html", "classMagellan_1_1DataModel_1_1Mdns" ],
        [ "NetworkAddress", "classMagellan_1_1DataModel_1_1NetworkAddress.html", "classMagellan_1_1DataModel_1_1NetworkAddress" ],
        [ "NetworkOptions", "classMagellan_1_1DataModel_1_1NetworkOptions.html", "classMagellan_1_1DataModel_1_1NetworkOptions" ],
        [ "Presence", "classMagellan_1_1DataModel_1_1Presence.html", "classMagellan_1_1DataModel_1_1Presence" ],
        [ "Rallypoint", "classMagellan_1_1DataModel_1_1Rallypoint.html", "classMagellan_1_1DataModel_1_1Rallypoint" ],
        [ "RestLink", "classMagellan_1_1DataModel_1_1RestLink.html", "classMagellan_1_1DataModel_1_1RestLink" ],
        [ "Ssdp", "classMagellan_1_1DataModel_1_1Ssdp.html", "classMagellan_1_1DataModel_1_1Ssdp" ],
        [ "SsdpNetworkAddress", "classMagellan_1_1DataModel_1_1SsdpNetworkAddress.html", "classMagellan_1_1DataModel_1_1SsdpNetworkAddress" ],
        [ "Talkgroup", "classMagellan_1_1DataModel_1_1Talkgroup.html", "classMagellan_1_1DataModel_1_1Talkgroup" ],
        [ "TalkgroupSecurity", "classMagellan_1_1DataModel_1_1TalkgroupSecurity.html", "classMagellan_1_1DataModel_1_1TalkgroupSecurity" ],
        [ "ThingInfo", "classMagellan_1_1DataModel_1_1ThingInfo.html", "classMagellan_1_1DataModel_1_1ThingInfo" ],
        [ "TxAudio", "classMagellan_1_1DataModel_1_1TxAudio.html", "classMagellan_1_1DataModel_1_1TxAudio" ]
      ] ],
      [ "AppDiscoverer", "classMagellan_1_1AppDiscoverer.html", "classMagellan_1_1AppDiscoverer" ],
      [ "AvahiDiscoverer", "classMagellan_1_1AvahiDiscoverer.html", "classMagellan_1_1AvahiDiscoverer" ],
      [ "BonjourDiscoverer", "classMagellan_1_1BonjourDiscoverer.html", "classMagellan_1_1BonjourDiscoverer" ],
      [ "Discoverer", "classMagellan_1_1Discoverer.html", "classMagellan_1_1Discoverer" ],
      [ "ILogger", "classMagellan_1_1ILogger.html", "classMagellan_1_1ILogger" ],
      [ "lssdp_packet", "structMagellan_1_1lssdp__packet.html", "structMagellan_1_1lssdp__packet" ],
      [ "MagellanObject", "classMagellan_1_1MagellanObject.html", "classMagellan_1_1MagellanObject" ],
      [ "ReferenceCountedObject", "classMagellan_1_1ReferenceCountedObject.html", "classMagellan_1_1ReferenceCountedObject" ],
      [ "Sem", "classMagellan_1_1Sem.html", "classMagellan_1_1Sem" ],
      [ "SimpleLogger", "classMagellan_1_1SimpleLogger.html", "classMagellan_1_1SimpleLogger" ],
      [ "SsdpDiscoverer", "classMagellan_1_1SsdpDiscoverer.html", "classMagellan_1_1SsdpDiscoverer" ],
      [ "TimerManager", "classMagellan_1_1TimerManager.html", "classMagellan_1_1TimerManager" ],
      [ "WorkQueue", "classMagellan_1_1WorkQueue.html", "classMagellan_1_1WorkQueue" ]
    ] ]
];