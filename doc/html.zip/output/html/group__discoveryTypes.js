var group__discoveryTypes =
[
    [ "MAGELLAN_APPLICATION_DISCOVERY_TYPE", "group__discoveryTypes.html#gaea211f6f668651c5641c81fdde0ba9f7", null ],
    [ "MAGELLAN_CISTECH_DISCOVERYTYPE", "group__discoveryTypes.html#gaded3ceea0140f011001b6e3c14a2eb80", null ],
    [ "MAGELLAN_DEFAULT_DISCOVERY_TYPE", "group__discoveryTypes.html#ga562a181441955af3ce5e552aad4a219b", null ],
    [ "MAGELLAN_MDNS_DISCOVERY_TYPE", "group__discoveryTypes.html#gaa2b2a1bfb05c8603cef5c4d5ca5b6b7d", null ],
    [ "MAGELLAN_SSDP_DISCOVERY_TYPE", "group__discoveryTypes.html#gaff13bb340f3c22d16813c33cc08120eb", null ],
    [ "MAGELLAN_TRELLISWAREDISCOVERY_TYPE", "group__discoveryTypes.html#gaaa25cd341596953093478cd7e08bf021", null ],
    [ "MAGELLAN_VOCALITY_DISCOVERY_TYPE", "group__discoveryTypes.html#ga316727046a98f0468dfcc4c0d35b1d49", null ]
];