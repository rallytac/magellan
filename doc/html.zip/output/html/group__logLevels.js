var group__logLevels =
[
    [ "MAGELLAN_LOG_LEVEL_DEBUG", "group__logLevels.html#ga22eb3bd25b1cf190d6be3447a206932c", null ],
    [ "MAGELLAN_LOG_LEVEL_ERROR", "group__logLevels.html#ga0ce5e7bcbda3b9f4748262468e65a4a7", null ],
    [ "MAGELLAN_LOG_LEVEL_FATAL", "group__logLevels.html#ga42f6ee6714d076d535859472d66c38a9", null ],
    [ "MAGELLAN_LOG_LEVEL_INFORMATIONAL", "group__logLevels.html#gaf5c7ab0f25a047179c33898155f1fb70", null ],
    [ "MAGELLAN_LOG_LEVEL_WARNING", "group__logLevels.html#ga4858de34b62a8b42d6458065a7144981", null ]
];