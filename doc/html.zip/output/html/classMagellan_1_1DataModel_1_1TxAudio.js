var classMagellan_1_1DataModel_1_1TxAudio =
[
    [ "TxAudio", "classMagellan_1_1DataModel_1_1TxAudio.html#a272d991cea83d75ebc9413f92f91cf24", null ],
    [ "clear", "classMagellan_1_1DataModel_1_1TxAudio.html#a3235c9fed62c7f2f9bdd1a132ca43916", null ],
    [ "matches", "classMagellan_1_1DataModel_1_1TxAudio.html#a067f987e8fc5130320400b610dadd2aa", null ],
    [ "encoder", "classMagellan_1_1DataModel_1_1TxAudio.html#a83aef8ed571427bb10b2f72b3937ef38", null ],
    [ "extensionSendInterval", "classMagellan_1_1DataModel_1_1TxAudio.html#a17526cdc3a6645f7dd96bb4d04d9bd5f", null ],
    [ "fdx", "classMagellan_1_1DataModel_1_1TxAudio.html#a699c6bcc62401f4217cbdb54b022ad87", null ],
    [ "framingMs", "classMagellan_1_1DataModel_1_1TxAudio.html#a9c71e49103c585862f2271cb74aacee8", null ],
    [ "initialHeaderBurst", "classMagellan_1_1DataModel_1_1TxAudio.html#ad32d663b509afeb2b9e30496e10cc80d", null ],
    [ "maxTxSecs", "classMagellan_1_1DataModel_1_1TxAudio.html#ab1588ab7da0027812dccca1ee00f467c", null ],
    [ "noHdrExt", "classMagellan_1_1DataModel_1_1TxAudio.html#ac8a6c9171a4b7d10dd73355a496ae235", null ],
    [ "trailingHeaderBurst", "classMagellan_1_1DataModel_1_1TxAudio.html#a9d02233ad613871d17ec23b5cddd3fad", null ]
];