var classMagellan_1_1MagellanObject =
[
    [ "MagellanObject", "classMagellan_1_1MagellanObject.html#a64ceaf645c300b8967c5ac56a1f07478", null ],
    [ "~MagellanObject", "classMagellan_1_1MagellanObject.html#af980f3dc0be5caa506af4773e01269d9", null ]
];