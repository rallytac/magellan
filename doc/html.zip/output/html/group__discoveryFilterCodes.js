var group__discoveryFilterCodes =
[
    [ "MAGELLAN_FILTER_IGNORE", "group__discoveryFilterCodes.html#ga264091df8664312e6dcbc8c9b2077673", null ],
    [ "MAGELLAN_FILTER_PROCEED", "group__discoveryFilterCodes.html#ga3e590a8bcc80cdfe85c322f1d28f0edf", null ]
];