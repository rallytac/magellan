var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "AppDiscoverer.hpp", "AppDiscoverer_8hpp_source.html", null ],
    [ "AvahiDiscoverer.hpp", "AvahiDiscoverer_8hpp_source.html", null ],
    [ "BonjourDiscoverer.hpp", "BonjourDiscoverer_8hpp_source.html", null ],
    [ "Discoverer.hpp", "Discoverer_8hpp_source.html", null ],
    [ "ILogger.hpp", "ILogger_8hpp_source.html", null ],
    [ "MagellanApi.h", "MagellanApi_8h.html", "MagellanApi_8h" ],
    [ "MagellanConstants.h", "MagellanConstants_8h.html", "MagellanConstants_8h" ],
    [ "MagellanCore.hpp", "MagellanCore_8hpp_source.html", null ],
    [ "MagellanDataModel.hpp", "MagellanDataModel_8hpp_source.html", null ],
    [ "MagellanObject.hpp", "MagellanObject_8hpp_source.html", null ],
    [ "MagellanTypes.h", "MagellanTypes_8h_source.html", null ],
    [ "ReferenceCountedObject.hpp", "ReferenceCountedObject_8hpp_source.html", null ],
    [ "Sem.hpp", "Sem_8hpp_source.html", null ],
    [ "SimpleLogger.hpp", "SimpleLogger_8hpp_source.html", null ],
    [ "SsdpDiscoverer.hpp", "SsdpDiscoverer_8hpp_source.html", null ],
    [ "TimerManager.hpp", "TimerManager_8hpp_source.html", null ],
    [ "WorkQueue.hpp", "WorkQueue_8hpp_source.html", null ]
];