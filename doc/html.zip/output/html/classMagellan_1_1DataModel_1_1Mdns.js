var classMagellan_1_1DataModel_1_1Mdns =
[
    [ "Mdns", "classMagellan_1_1DataModel_1_1Mdns.html#a1d677aacc058a5489abda9640e01f224", null ],
    [ "clear", "classMagellan_1_1DataModel_1_1Mdns.html#a052f60adce209c053ab53c14ec0ecf0b", null ],
    [ "setDefaultsIfNecessary", "classMagellan_1_1DataModel_1_1Mdns.html#ac9f38aea5dccd1e484a937ae737d0546", null ],
    [ "serviceType", "classMagellan_1_1DataModel_1_1Mdns.html#a47e8015def29d6c0487bce1ef94a2287", null ]
];