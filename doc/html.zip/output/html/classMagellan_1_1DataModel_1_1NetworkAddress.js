var classMagellan_1_1DataModel_1_1NetworkAddress =
[
    [ "NetworkAddress", "classMagellan_1_1DataModel_1_1NetworkAddress.html#a350892014c4cb3bcbb49b3d3dfd5d3cd", null ],
    [ "clear", "classMagellan_1_1DataModel_1_1NetworkAddress.html#acbce1d006c783aa07f41acb5866b20ae", null ],
    [ "matches", "classMagellan_1_1DataModel_1_1NetworkAddress.html#a6feae82bdbeb8fdd8090c576033be5e1", null ],
    [ "address", "classMagellan_1_1DataModel_1_1NetworkAddress.html#a09715f771119596159309c1aaa6b8380", null ],
    [ "port", "classMagellan_1_1DataModel_1_1NetworkAddress.html#a51e4c3d4ed4f42512aa4198473ecf330", null ]
];