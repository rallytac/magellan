var classMagellan_1_1DataModel_1_1NetworkOptions =
[
    [ "NetworkOptions", "classMagellan_1_1DataModel_1_1NetworkOptions.html#a8d79b3139d555d3fa2c9b8c2017349ae", null ],
    [ "clear", "classMagellan_1_1DataModel_1_1NetworkOptions.html#ab391e722d92feeff355f4cbd3d2b84d0", null ],
    [ "matches", "classMagellan_1_1DataModel_1_1NetworkOptions.html#a2fe2eaa82ad4723f13272aac4132d693", null ],
    [ "priority", "classMagellan_1_1DataModel_1_1NetworkOptions.html#a29d91434ed8163be9cebb8d13b0a2066", null ],
    [ "ttl", "classMagellan_1_1DataModel_1_1NetworkOptions.html#a4b6ad419515ef3b57c557fce85898fee", null ]
];