var modules =
[
    [ "Magellan Result Codes", "group__resultCodes.html", "group__resultCodes" ],
    [ "Magellan Logging Levels", "group__logLevels.html", "group__logLevels" ],
    [ "Magellan Discovery Types", "group__discoveryTypes.html", "group__discoveryTypes" ],
    [ "Magellan Discovery Filter Codes", "group__discoveryFilterCodes.html", "group__discoveryFilterCodes" ]
];