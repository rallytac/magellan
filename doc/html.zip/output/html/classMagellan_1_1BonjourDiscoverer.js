var classMagellan_1_1BonjourDiscoverer =
[
    [ "BonjourDiscoverer", "classMagellan_1_1BonjourDiscoverer.html#a075ce6cd7102920433830e35b7cc2250", null ],
    [ "~BonjourDiscoverer", "classMagellan_1_1BonjourDiscoverer.html#adc28fa924bab0ba9f2e7aabb0aa5c2e8", null ],
    [ "configure", "classMagellan_1_1BonjourDiscoverer.html#a692420e95d4766f84cbf8689008920f9", null ],
    [ "deleteThis", "classMagellan_1_1BonjourDiscoverer.html#af24724cff7cefeddfefe96e5f693aec6", null ],
    [ "pause", "classMagellan_1_1BonjourDiscoverer.html#ae3361cd3d88a97347fee2f14ec2d0e72", null ],
    [ "resume", "classMagellan_1_1BonjourDiscoverer.html#abffd5fef5098f926372e059355e47a98", null ],
    [ "start", "classMagellan_1_1BonjourDiscoverer.html#abe6873757a125c7985ae9759083379d6", null ],
    [ "stop", "classMagellan_1_1BonjourDiscoverer.html#a67044258e11fae8c6a1b2a7dad531c1f", null ]
];