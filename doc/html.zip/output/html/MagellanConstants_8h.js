var MagellanConstants_8h =
[
    [ "MAGELLAN_APPLICATION_DISCOVERY_TYPE", "group__discoveryTypes.html#gaea211f6f668651c5641c81fdde0ba9f7", null ],
    [ "MAGELLAN_CISTECH_DISCOVERYTYPE", "group__discoveryTypes.html#gaded3ceea0140f011001b6e3c14a2eb80", null ],
    [ "MAGELLAN_DEFAULT_DISCOVERY_TYPE", "group__discoveryTypes.html#ga562a181441955af3ce5e552aad4a219b", null ],
    [ "MAGELLAN_MDNS_DISCOVERY_TYPE", "group__discoveryTypes.html#gaa2b2a1bfb05c8603cef5c4d5ca5b6b7d", null ],
    [ "MAGELLAN_NULL_TOKEN", "MagellanConstants_8h.html#ada42189edae50bc83825ba9fd052c8f5", null ],
    [ "MAGELLAN_SSDP_DISCOVERY_TYPE", "group__discoveryTypes.html#gaff13bb340f3c22d16813c33cc08120eb", null ],
    [ "MAGELLAN_TRELLISWAREDISCOVERY_TYPE", "group__discoveryTypes.html#gaaa25cd341596953093478cd7e08bf021", null ],
    [ "MAGELLAN_VOCALITY_DISCOVERY_TYPE", "group__discoveryTypes.html#ga316727046a98f0468dfcc4c0d35b1d49", null ],
    [ "MAGELLAN_FILTER_IGNORE", "group__discoveryFilterCodes.html#ga264091df8664312e6dcbc8c9b2077673", null ],
    [ "MAGELLAN_FILTER_PROCEED", "group__discoveryFilterCodes.html#ga3e590a8bcc80cdfe85c322f1d28f0edf", null ],
    [ "MAGELLAN_LOG_LEVEL_DEBUG", "group__logLevels.html#ga22eb3bd25b1cf190d6be3447a206932c", null ],
    [ "MAGELLAN_LOG_LEVEL_ERROR", "group__logLevels.html#ga0ce5e7bcbda3b9f4748262468e65a4a7", null ],
    [ "MAGELLAN_LOG_LEVEL_FATAL", "group__logLevels.html#ga42f6ee6714d076d535859472d66c38a9", null ],
    [ "MAGELLAN_LOG_LEVEL_INFORMATIONAL", "group__logLevels.html#gaf5c7ab0f25a047179c33898155f1fb70", null ],
    [ "MAGELLAN_LOG_LEVEL_WARNING", "group__logLevels.html#ga4858de34b62a8b42d6458065a7144981", null ],
    [ "MAGELLAN_RESULT_ALREADY_INITIALIZED", "group__resultCodes.html#gacc8d9e9e0224f938c3662d002f6ed1a1", null ],
    [ "MAGELLAN_RESULT_GENERAL_FAILURE", "group__resultCodes.html#ga31a041e6577153417d99ade7de467f19", null ],
    [ "MAGELLAN_RESULT_INVALID_PARAMETERS", "group__resultCodes.html#gadf874eccfba2c44a873e73827a8a74c0", null ],
    [ "MAGELLAN_RESULT_NOT_INITIALIZED", "group__resultCodes.html#ga78aecabc00b8a6df30be79157c9b7dec", null ],
    [ "MAGELLAN_RESULT_OK", "group__resultCodes.html#gaeba1be517178dbaeb5038c1579dc8d2f", null ]
];