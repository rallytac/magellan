var classMagellan_1_1DataModel_1_1DiscoveredDevice =
[
    [ "DiscoveredDevice", "classMagellan_1_1DataModel_1_1DiscoveredDevice.html#a362fd68cfd5d797c6b859b7a7d810307", null ],
    [ "clear", "classMagellan_1_1DataModel_1_1DiscoveredDevice.html#abc81e3a6356bc619470b42a165338295", null ],
    [ "configVersion", "classMagellan_1_1DataModel_1_1DiscoveredDevice.html#a4241f74ea443b57aa233dd7a2ce35e9c", null ],
    [ "discovererKey", "classMagellan_1_1DataModel_1_1DiscoveredDevice.html#a94d3715665b761c11580f24b438f88ce", null ],
    [ "id", "classMagellan_1_1DataModel_1_1DiscoveredDevice.html#af67b4848d29d9cc8b4305436b5e3ade0", null ],
    [ "rootUrl", "classMagellan_1_1DataModel_1_1DiscoveredDevice.html#a37ee476101a574e42744a507be9a4f35", null ]
];