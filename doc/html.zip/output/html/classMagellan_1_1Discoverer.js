var classMagellan_1_1Discoverer =
[
    [ "Discoverer", "classMagellan_1_1Discoverer.html#ad0470c623f9367d3c7bb56f77a7cf4a2", null ],
    [ "~Discoverer", "classMagellan_1_1Discoverer.html#ae0fb97460cbc04ea79c3f259a8723f89", null ],
    [ "callFilterHook", "classMagellan_1_1Discoverer.html#af5b07473d615d59bb53f055f986c5ad7", null ],
    [ "configure", "classMagellan_1_1Discoverer.html#a44a9d1d462e6c4473d0a29f1d7f04969", null ],
    [ "getFilterHook", "classMagellan_1_1Discoverer.html#a5cfc8ae6b19eba36b0670d78953ee4c3", null ],
    [ "getImplementation", "classMagellan_1_1Discoverer.html#a85d81539e8528b53406cd180d7903013", null ],
    [ "getUserData", "classMagellan_1_1Discoverer.html#a80514bec24a3b551f916750713ae4163", null ],
    [ "getWorkQueue", "classMagellan_1_1Discoverer.html#a8b18d5618377bd8638ce4fba9f6a3934", null ],
    [ "pause", "classMagellan_1_1Discoverer.html#ae133c2665e2f01ff2ecc2937500ef98c", null ],
    [ "resume", "classMagellan_1_1Discoverer.html#a1fb35357552bce2910c031da48fa547e", null ],
    [ "setHook", "classMagellan_1_1Discoverer.html#aea506dce9678b31cc78a07e0af68ba69", null ],
    [ "setImplementation", "classMagellan_1_1Discoverer.html#ac631b3627fc080dd239b4b7ac3732765", null ],
    [ "setUserData", "classMagellan_1_1Discoverer.html#aed385e9adbe5861c29839a13b45ebc69", null ],
    [ "setWorkQueue", "classMagellan_1_1Discoverer.html#a0f7c6abee791796bab35a1dada89ce22", null ],
    [ "start", "classMagellan_1_1Discoverer.html#a255518435d23860ffa6fc32c665cbf15", null ],
    [ "stop", "classMagellan_1_1Discoverer.html#a38d21e13555fe2e9a5e3a13379a11221", null ]
];