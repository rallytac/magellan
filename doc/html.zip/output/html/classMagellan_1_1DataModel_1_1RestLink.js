var classMagellan_1_1DataModel_1_1RestLink =
[
    [ "RestLink", "classMagellan_1_1DataModel_1_1RestLink.html#a0bee4a2088cec9c1b778c4aacb0cf905", null ],
    [ "clear", "classMagellan_1_1DataModel_1_1RestLink.html#a73f2c117ee8a3f065b52922a483f334e", null ],
    [ "abandonUrlsAfterConsecutiveErrors", "classMagellan_1_1DataModel_1_1RestLink.html#a948e4631bfe6b3cd9df42d7246feeb0f", null ],
    [ "caBundle", "classMagellan_1_1DataModel_1_1RestLink.html#a34a56defde7e2af74b099a80bac9c9d0", null ],
    [ "certFile", "classMagellan_1_1DataModel_1_1RestLink.html#a3d975918d866509ffcd189bc0b164ac2", null ],
    [ "certPass", "classMagellan_1_1DataModel_1_1RestLink.html#a6a57928ff1852dcf5652c6a3043a10c3", null ],
    [ "keyFile", "classMagellan_1_1DataModel_1_1RestLink.html#a5c95de3319d37912bbaa35c4f98207d0", null ],
    [ "keyPass", "classMagellan_1_1DataModel_1_1RestLink.html#ad2dfa8825d5bda2075fe63e6fb852aa2", null ],
    [ "logUrlOperation", "classMagellan_1_1DataModel_1_1RestLink.html#af8829e73da38f4a0c88750bf82996107", null ],
    [ "maxUrlConsecutiveErrors", "classMagellan_1_1DataModel_1_1RestLink.html#ae96894db8ea957477bfd86205af38e55", null ],
    [ "urlCheckerIntervalMs", "classMagellan_1_1DataModel_1_1RestLink.html#ab78f81310f68710cd8b054906629bdd5", null ],
    [ "urlRetryIntervalMs", "classMagellan_1_1DataModel_1_1RestLink.html#a1b6fb519ccd3e4e699756cf445fe69a3", null ],
    [ "verifyHost", "classMagellan_1_1DataModel_1_1RestLink.html#ac367d463a17a7736f66bd4dc104ad58f", null ],
    [ "verifyPeer", "classMagellan_1_1DataModel_1_1RestLink.html#a534ccf38eaaa6a1df19c449c79ba1e30", null ]
];