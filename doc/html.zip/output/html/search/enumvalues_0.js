var searchData=
[
  ['debug',['debug',['../classMagellan_1_1ILogger.html#ab4fe76c1bd3523d49bb31b1a0d2d7bf1ac2181dbfd3a5b2292d64a13ebb50cba7',1,'Magellan::ILogger']]]
];
