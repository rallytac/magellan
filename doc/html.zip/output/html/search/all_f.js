var searchData=
[
  ['pause',['pause',['../classMagellan_1_1AppDiscoverer.html#ae1faa805879d394cd34fd27b124b4376',1,'Magellan::AppDiscoverer::pause()'],['../classMagellan_1_1AvahiDiscoverer.html#a2b05c65a3b57e7e78681c244030b5113',1,'Magellan::AvahiDiscoverer::pause()'],['../classMagellan_1_1BonjourDiscoverer.html#ae3361cd3d88a97347fee2f14ec2d0e72',1,'Magellan::BonjourDiscoverer::pause()'],['../classMagellan_1_1Discoverer.html#ae133c2665e2f01ff2ecc2937500ef98c',1,'Magellan::Discoverer::pause()'],['../classMagellan_1_1SsdpDiscoverer.html#acba31a6f8f4bcf852b5c632174322b6c',1,'Magellan::SsdpDiscoverer::pause()']]],
  ['port',['port',['../classMagellan_1_1DataModel_1_1NetworkAddress.html#a51e4c3d4ed4f42512aa4198473ecf330',1,'Magellan::DataModel::NetworkAddress']]],
  ['presence',['Presence',['../classMagellan_1_1DataModel_1_1Presence.html',1,'Magellan::DataModel::Presence'],['../classMagellan_1_1DataModel_1_1Talkgroup.html#a3ae67cffd04ff93a4f83777acfd16129',1,'Magellan::DataModel::Talkgroup::presence()']]],
  ['priority',['priority',['../classMagellan_1_1DataModel_1_1NetworkOptions.html#a29d91434ed8163be9cebb8d13b0a2066',1,'Magellan::DataModel::NetworkOptions']]]
];
