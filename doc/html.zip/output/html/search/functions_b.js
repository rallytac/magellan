var searchData=
[
  ['sem',['Sem',['../classMagellan_1_1Sem.html#a6f6dbe9f83a42b7b27cc489231805573',1,'Magellan::Sem']]],
  ['sethook',['setHook',['../classMagellan_1_1Discoverer.html#aea506dce9678b31cc78a07e0af68ba69',1,'Magellan::Discoverer']]],
  ['setimplementation',['setImplementation',['../classMagellan_1_1Discoverer.html#ac631b3627fc080dd239b4b7ac3732765',1,'Magellan::Discoverer']]],
  ['setmaxdepth',['setMaxDepth',['../classMagellan_1_1WorkQueue.html#a6c8e6aca8b2d25fcc40f01fbd7e2bab1',1,'Magellan::WorkQueue']]],
  ['setmaxlevel',['setMaxLevel',['../classMagellan_1_1ILogger.html#ae4ce0a4f8f4d8b09210561ca9b9e312d',1,'Magellan::ILogger']]],
  ['setoutputhook',['setOutputHook',['../classMagellan_1_1SimpleLogger.html#a4842fb502e717358c9acd67822e118d3',1,'Magellan::SimpleLogger']]],
  ['setsyslogenabled',['setSyslogEnabled',['../classMagellan_1_1ILogger.html#a0b5ed1109bd359dfab6ec07829ded0e7',1,'Magellan::ILogger']]],
  ['setuserdata',['setUserData',['../classMagellan_1_1Discoverer.html#aed385e9adbe5861c29839a13b45ebc69',1,'Magellan::Discoverer']]],
  ['setworkqueue',['setWorkQueue',['../classMagellan_1_1Discoverer.html#a0f7c6abee791796bab35a1dada89ce22',1,'Magellan::Discoverer']]],
  ['simplelogger',['SimpleLogger',['../classMagellan_1_1SimpleLogger.html#a55bcad261a085141da58f9d271f44ad7',1,'Magellan::SimpleLogger']]],
  ['start',['start',['../classMagellan_1_1AppDiscoverer.html#ac41d20c9439f157c67aa014b81c674ab',1,'Magellan::AppDiscoverer::start()'],['../classMagellan_1_1AvahiDiscoverer.html#a04a7e7515fbed735fa0f0a1fb90a73fb',1,'Magellan::AvahiDiscoverer::start()'],['../classMagellan_1_1BonjourDiscoverer.html#abe6873757a125c7985ae9759083379d6',1,'Magellan::BonjourDiscoverer::start()'],['../classMagellan_1_1Discoverer.html#a255518435d23860ffa6fc32c665cbf15',1,'Magellan::Discoverer::start()'],['../classMagellan_1_1SsdpDiscoverer.html#a881e6025aedc1687344abcd520eca3b9',1,'Magellan::SsdpDiscoverer::start()'],['../classMagellan_1_1WorkQueue.html#ab8b3faa13455d0bd1c5b190b3fc35b0d',1,'Magellan::WorkQueue::start()']]],
  ['stop',['stop',['../classMagellan_1_1AppDiscoverer.html#a96d50102bee764a38e3e6b75ef636680',1,'Magellan::AppDiscoverer::stop()'],['../classMagellan_1_1AvahiDiscoverer.html#adb5e31eff58497a506d3f828e9282dc8',1,'Magellan::AvahiDiscoverer::stop()'],['../classMagellan_1_1BonjourDiscoverer.html#a67044258e11fae8c6a1b2a7dad531c1f',1,'Magellan::BonjourDiscoverer::stop()'],['../classMagellan_1_1Discoverer.html#a38d21e13555fe2e9a5e3a13379a11221',1,'Magellan::Discoverer::stop()'],['../classMagellan_1_1SsdpDiscoverer.html#ac39e9c73792db39b955f35ef6a7fa3cd',1,'Magellan::SsdpDiscoverer::stop()'],['../classMagellan_1_1WorkQueue.html#a1f9c96a93bc99102854aa652ffdbc00c',1,'Magellan::WorkQueue::stop()']]],
  ['submit',['submit',['../classMagellan_1_1WorkQueue.html#a439d7e493d81db8d8ec3f86154ce9c1e',1,'Magellan::WorkQueue']]],
  ['submitandwait',['submitAndWait',['../classMagellan_1_1WorkQueue.html#ab1988ab3d969721ab08c0c05b99bb4ee',1,'Magellan::WorkQueue']]]
];
