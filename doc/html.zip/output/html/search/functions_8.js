var searchData=
[
  ['notify',['notify',['../classMagellan_1_1Sem.html#afa3f1c61a967e3ca5b1147a9be20cd0a',1,'Magellan::Sem']]]
];
