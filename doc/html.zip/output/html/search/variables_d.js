var searchData=
[
  ['rallypoints',['rallypoints',['../classMagellan_1_1DataModel_1_1Talkgroup.html#a5ca4a4aebfa5e8b56d550a05268c838e',1,'Magellan::DataModel::Talkgroup']]],
  ['restlink',['restLink',['../classMagellan_1_1DataModel_1_1MagellanConfiguration.html#a1eb3d330c50db9e491586a56cfc8c08e',1,'Magellan::DataModel::MagellanConfiguration']]],
  ['rooturl',['rootUrl',['../classMagellan_1_1DataModel_1_1DiscoveredDevice.html#a37ee476101a574e42744a507be9a4f35',1,'Magellan::DataModel::DiscoveredDevice']]],
  ['rx',['rx',['../classMagellan_1_1DataModel_1_1Talkgroup.html#a3821e838a2f6ecd876cb36f0080ea4ff',1,'Magellan::DataModel::Talkgroup']]]
];
