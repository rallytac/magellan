var searchData=
[
  ['getfilterhook',['getFilterHook',['../classMagellan_1_1Discoverer.html#a5cfc8ae6b19eba36b0670d78953ee4c3',1,'Magellan::Discoverer']]],
  ['getimplementation',['getImplementation',['../classMagellan_1_1Discoverer.html#a85d81539e8528b53406cd180d7903013',1,'Magellan::Discoverer']]],
  ['getmaxdepth',['getMaxDepth',['../classMagellan_1_1WorkQueue.html#a370f05c3e00e52ed64ba1e37ff1479e0',1,'Magellan::WorkQueue']]],
  ['getmaxlevel',['getMaxLevel',['../classMagellan_1_1ILogger.html#ad5def5b76223847ea986fbd0ca936a7e',1,'Magellan::ILogger']]],
  ['getuserdata',['getUserData',['../classMagellan_1_1Discoverer.html#a80514bec24a3b551f916750713ae4163',1,'Magellan::Discoverer']]],
  ['getworkqueue',['getWorkQueue',['../classMagellan_1_1Discoverer.html#a8b18d5618377bd8638ce4fba9f6a3934',1,'Magellan::Discoverer']]]
];
