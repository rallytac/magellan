var searchData=
[
  ['ilogger',['ILogger',['../classMagellan_1_1ILogger.html',1,'Magellan']]]
];
