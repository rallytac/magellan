var searchData=
[
  ['security',['security',['../classMagellan_1_1DataModel_1_1Talkgroup.html#a3aff6dd273efdee43074784e064cb8bf',1,'Magellan::DataModel::Talkgroup']]],
  ['servicetype',['serviceType',['../classMagellan_1_1DataModel_1_1Mdns.html#a47e8015def29d6c0487bce1ef94a2287',1,'Magellan::DataModel::Mdns']]],
  ['ssdp',['ssdp',['../classMagellan_1_1DataModel_1_1MagellanConfiguration.html#ae09f3434929b8bac91db8dca704965f8',1,'Magellan::DataModel::MagellanConfiguration']]],
  ['st',['st',['../classMagellan_1_1DataModel_1_1Ssdp.html#a17bf71ad7bdb521cf98a66434e2f4fd0',1,'Magellan::DataModel::Ssdp']]],
  ['staleneighorcheckintervalms',['staleNeighorCheckIntervalMs',['../classMagellan_1_1DataModel_1_1Ssdp.html#ad33cca03218574dc6128aee75b4416a0',1,'Magellan::DataModel::Ssdp']]]
];
