var searchData=
[
  ['magellanapi_2eh',['MagellanApi.h',['../MagellanApi_8h.html',1,'']]],
  ['magellanconstants_2eh',['MagellanConstants.h',['../MagellanConstants_8h.html',1,'']]]
];
