var searchData=
[
  ['pause',['pause',['../classMagellan_1_1AppDiscoverer.html#ae1faa805879d394cd34fd27b124b4376',1,'Magellan::AppDiscoverer::pause()'],['../classMagellan_1_1AvahiDiscoverer.html#a2b05c65a3b57e7e78681c244030b5113',1,'Magellan::AvahiDiscoverer::pause()'],['../classMagellan_1_1BonjourDiscoverer.html#ae3361cd3d88a97347fee2f14ec2d0e72',1,'Magellan::BonjourDiscoverer::pause()'],['../classMagellan_1_1Discoverer.html#ae133c2665e2f01ff2ecc2937500ef98c',1,'Magellan::Discoverer::pause()'],['../classMagellan_1_1SsdpDiscoverer.html#acba31a6f8f4bcf852b5c632174322b6c',1,'Magellan::SsdpDiscoverer::pause()']]]
];
