var searchData=
[
  ['host',['host',['../classMagellan_1_1DataModel_1_1Rallypoint.html#a61b14bf17f2f92d50ed9debd1355c598',1,'Magellan::DataModel::Rallypoint']]],
  ['housekeeperintervalms',['houseKeeperIntervalMs',['../classMagellan_1_1DataModel_1_1MagellanConfiguration.html#a3e5735c41c179ed577e2532a5308769a',1,'Magellan::DataModel::MagellanConfiguration']]]
];
