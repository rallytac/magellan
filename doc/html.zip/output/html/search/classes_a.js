var searchData=
[
  ['sem',['Sem',['../classMagellan_1_1Sem.html',1,'Magellan']]],
  ['simplelogger',['SimpleLogger',['../classMagellan_1_1SimpleLogger.html',1,'Magellan']]],
  ['ssdp',['Ssdp',['../classMagellan_1_1DataModel_1_1Ssdp.html',1,'Magellan::DataModel']]],
  ['ssdpdiscoverer',['SsdpDiscoverer',['../classMagellan_1_1SsdpDiscoverer.html',1,'Magellan']]],
  ['ssdpnetworkaddress',['SsdpNetworkAddress',['../classMagellan_1_1DataModel_1_1SsdpNetworkAddress.html',1,'Magellan::DataModel']]]
];
