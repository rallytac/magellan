var searchData=
[
  ['urlcheckerintervalms',['urlCheckerIntervalMs',['../classMagellan_1_1DataModel_1_1RestLink.html#ab78f81310f68710cd8b054906629bdd5',1,'Magellan::DataModel::RestLink']]],
  ['urlretryintervalms',['urlRetryIntervalMs',['../classMagellan_1_1DataModel_1_1RestLink.html#a1b6fb519ccd3e4e699756cf445fe69a3',1,'Magellan::DataModel::RestLink']]],
  ['useragent',['userAgent',['../classMagellan_1_1DataModel_1_1Ssdp.html#a65b0674294286f3d79956524486ea74c',1,'Magellan::DataModel::Ssdp']]]
];
