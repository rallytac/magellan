var searchData=
[
  ['bonjourdiscoverer',['BonjourDiscoverer',['../classMagellan_1_1BonjourDiscoverer.html',1,'Magellan']]]
];
