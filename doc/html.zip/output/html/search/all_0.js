var searchData=
[
  ['_5fenablesyslog',['_enableSyslog',['../classMagellan_1_1ILogger.html#afe3e37077581e1979b7ce62e668844b1',1,'Magellan::ILogger']]],
  ['_5fmaxlevel',['_maxLevel',['../classMagellan_1_1ILogger.html#aaf6219ebb701fabf3129f054eb740672',1,'Magellan::ILogger']]]
];
