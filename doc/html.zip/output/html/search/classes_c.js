var searchData=
[
  ['workqueue',['WorkQueue',['../classMagellan_1_1WorkQueue.html',1,'Magellan']]]
];
