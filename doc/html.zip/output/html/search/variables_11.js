var searchData=
[
  ['verifyhost',['verifyHost',['../classMagellan_1_1DataModel_1_1RestLink.html#ac367d463a17a7736f66bd4dc104ad58f',1,'Magellan::DataModel::RestLink']]],
  ['verifypeer',['verifyPeer',['../classMagellan_1_1DataModel_1_1RestLink.html#a534ccf38eaaa6a1df19c449c79ba1e30',1,'Magellan::DataModel::RestLink']]],
  ['version',['version',['../classMagellan_1_1DataModel_1_1DeviceConfiguration.html#a908b00ced52aa68b98f6ecce37354264',1,'Magellan::DataModel::DeviceConfiguration']]]
];
