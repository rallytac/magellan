var searchData=
[
  ['referencecountedobject',['ReferenceCountedObject',['../classMagellan_1_1ReferenceCountedObject.html#a6ec00c928c1efe12eda9cf4c546fc0a0',1,'Magellan::ReferenceCountedObject']]],
  ['releasereference',['releaseReference',['../classMagellan_1_1ReferenceCountedObject.html#a882bca099fea6d62321a51982f623667',1,'Magellan::ReferenceCountedObject']]],
  ['reset',['reset',['../classMagellan_1_1Sem.html#a80dace86d9a512e331335b4a304a4ebd',1,'Magellan::Sem::reset()'],['../classMagellan_1_1WorkQueue.html#a8793d4544077b8a4226756b704b56a65',1,'Magellan::WorkQueue::reset()']]],
  ['restart',['restart',['../classMagellan_1_1WorkQueue.html#af8e9e43a44d554e247cc5fdde55ed272',1,'Magellan::WorkQueue']]],
  ['resume',['resume',['../classMagellan_1_1AppDiscoverer.html#ad42c1b50dfc97ee502b9c3067b3a255b',1,'Magellan::AppDiscoverer::resume()'],['../classMagellan_1_1AvahiDiscoverer.html#a9453f717ea75f328330b5c28fb467aaa',1,'Magellan::AvahiDiscoverer::resume()'],['../classMagellan_1_1BonjourDiscoverer.html#abffd5fef5098f926372e059355e47a98',1,'Magellan::BonjourDiscoverer::resume()'],['../classMagellan_1_1Discoverer.html#a1fb35357552bce2910c031da48fa547e',1,'Magellan::Discoverer::resume()'],['../classMagellan_1_1SsdpDiscoverer.html#abbcdd326dd5bef272db95f92c7659579',1,'Magellan::SsdpDiscoverer::resume()']]]
];
