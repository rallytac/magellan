var searchData=
[
  ['jsonobjectbase',['JsonObjectBase',['../classMagellan_1_1DataModel_1_1JsonObjectBase.html',1,'Magellan::DataModel']]]
];
