var searchData=
[
  ['magellan',['Magellan',['../index.html',1,'']]]
];
