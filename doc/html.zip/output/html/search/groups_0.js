var searchData=
[
  ['magellan_20discovery_20filter_20codes',['Magellan Discovery Filter Codes',['../group__discoveryFilterCodes.html',1,'']]],
  ['magellan_20discovery_20types',['Magellan Discovery Types',['../group__discoveryTypes.html',1,'']]],
  ['magellan_20logging_20levels',['Magellan Logging Levels',['../group__logLevels.html',1,'']]],
  ['magellan_20result_20codes',['Magellan Result Codes',['../group__resultCodes.html',1,'']]]
];
