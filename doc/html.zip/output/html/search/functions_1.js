var searchData=
[
  ['callfilterhook',['callFilterHook',['../classMagellan_1_1Discoverer.html#af5b07473d615d59bb53f055f986c5ad7',1,'Magellan::Discoverer']]],
  ['configure',['configure',['../classMagellan_1_1AppDiscoverer.html#a4723996d2f03902608bf33f193262854',1,'Magellan::AppDiscoverer::configure()'],['../classMagellan_1_1AvahiDiscoverer.html#ac70b232c04590d6171ea6bca713f5695',1,'Magellan::AvahiDiscoverer::configure()'],['../classMagellan_1_1BonjourDiscoverer.html#a692420e95d4766f84cbf8689008920f9',1,'Magellan::BonjourDiscoverer::configure()'],['../classMagellan_1_1Discoverer.html#a44a9d1d462e6c4473d0a29f1d7f04969',1,'Magellan::Discoverer::configure()'],['../classMagellan_1_1SsdpDiscoverer.html#a99e94f2547fb1580336c49a7f099af5b',1,'Magellan::SsdpDiscoverer::configure()']]]
];
