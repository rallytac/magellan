var searchData=
[
  ['networkaddress',['NetworkAddress',['../classMagellan_1_1DataModel_1_1NetworkAddress.html',1,'Magellan::DataModel']]],
  ['networkoptions',['NetworkOptions',['../classMagellan_1_1DataModel_1_1NetworkOptions.html',1,'Magellan::DataModel']]]
];
