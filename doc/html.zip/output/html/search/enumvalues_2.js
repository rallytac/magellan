var searchData=
[
  ['fatal',['fatal',['../classMagellan_1_1ILogger.html#ab4fe76c1bd3523d49bb31b1a0d2d7bf1a8b049bc37b7e6f19a733215710bce1f1',1,'Magellan::ILogger']]]
];
