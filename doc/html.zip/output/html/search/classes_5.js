var searchData=
[
  ['lssdp_5fpacket',['lssdp_packet',['../structMagellan_1_1lssdp__packet.html',1,'Magellan']]]
];
