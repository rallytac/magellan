var searchData=
[
  ['magellanbegindiscovery',['magellanBeginDiscovery',['../MagellanApi_8h.html#a005b91994aa0c659b774db6381ef4730',1,'MagellanApi.h']]],
  ['magellanenddiscovery',['magellanEndDiscovery',['../MagellanApi_8h.html#a5b709ba6628497dae95191a78d650c59',1,'MagellanApi.cpp']]],
  ['magellaninitialize',['magellanInitialize',['../MagellanApi_8h.html#a5cb6434bb0ca5dd36558d9ebb4ceb874',1,'MagellanApi.cpp']]],
  ['magellanlogmessage',['magellanLogMessage',['../MagellanApi_8h.html#a895c21189d0318db2cdb74fbabb5f052',1,'MagellanApi.cpp']]],
  ['magellanobject',['MagellanObject',['../classMagellan_1_1MagellanObject.html#a64ceaf645c300b8967c5ac56a1f07478',1,'Magellan::MagellanObject']]],
  ['magellanpausediscovery',['magellanPauseDiscovery',['../MagellanApi_8h.html#a29228e3a54d03e2a438789bbd832094c',1,'MagellanApi.cpp']]],
  ['magellanresumediscovery',['magellanResumeDiscovery',['../MagellanApi_8h.html#a19101f1726468ab9c727b5c8a3d15d0e',1,'MagellanApi.cpp']]],
  ['magellansetlogginghook',['magellanSetLoggingHook',['../MagellanApi_8h.html#a3df0c637708ef7daed1d510d2b139e6b',1,'MagellanApi.cpp']]],
  ['magellansetlogginglevel',['magellanSetLoggingLevel',['../MagellanApi_8h.html#a5227a1ec7ca9d61ef6d192cd2d53d172',1,'MagellanApi.cpp']]],
  ['magellansettalkgroupcallbacks',['magellanSetTalkgroupCallbacks',['../MagellanApi_8h.html#aea463cb1142b80a37f83715f7a1ee946',1,'MagellanApi.cpp']]],
  ['magellanshutdown',['magellanShutdown',['../MagellanApi_8h.html#a4855c480145d6e4ba3c7ba7bf7226526',1,'MagellanApi.cpp']]]
];
