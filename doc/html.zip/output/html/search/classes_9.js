var searchData=
[
  ['rallypoint',['Rallypoint',['../classMagellan_1_1DataModel_1_1Rallypoint.html',1,'Magellan::DataModel']]],
  ['referencecountedobject',['ReferenceCountedObject',['../classMagellan_1_1ReferenceCountedObject.html',1,'Magellan']]],
  ['restlink',['RestLink',['../classMagellan_1_1DataModel_1_1RestLink.html',1,'Magellan::DataModel']]]
];
