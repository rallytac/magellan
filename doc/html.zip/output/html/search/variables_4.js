var searchData=
[
  ['encoder',['encoder',['../classMagellan_1_1DataModel_1_1TxAudio.html#a83aef8ed571427bb10b2f72b3937ef38',1,'Magellan::DataModel::TxAudio']]],
  ['extensionsendinterval',['extensionSendInterval',['../classMagellan_1_1DataModel_1_1TxAudio.html#a17526cdc3a6645f7dd96bb4d04d9bd5f',1,'Magellan::DataModel::TxAudio']]]
];
