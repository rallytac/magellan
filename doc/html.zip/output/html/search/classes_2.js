var searchData=
[
  ['deviceconfiguration',['DeviceConfiguration',['../classMagellan_1_1DataModel_1_1DeviceConfiguration.html',1,'Magellan::DataModel']]],
  ['deviceconfigurationdownloadctx',['DeviceConfigurationDownloadCtx',['../classMagellan_1_1Core_1_1DeviceConfigurationDownloadCtx.html',1,'Magellan::Core']]],
  ['devicetracker',['DeviceTracker',['../classMagellan_1_1Core_1_1DeviceTracker.html',1,'Magellan::Core']]],
  ['discovereddevice',['DiscoveredDevice',['../classMagellan_1_1DataModel_1_1DiscoveredDevice.html',1,'Magellan::DataModel']]],
  ['discoverer',['Discoverer',['../classMagellan_1_1Discoverer.html',1,'Magellan']]]
];
