var searchData=
[
  ['level',['Level',['../classMagellan_1_1ILogger.html#ab4fe76c1bd3523d49bb31b1a0d2d7bf1',1,'Magellan::ILogger']]]
];
