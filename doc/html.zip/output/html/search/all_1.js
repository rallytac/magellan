var searchData=
[
  ['abandonurlsafterconsecutiveerrors',['abandonUrlsAfterConsecutiveErrors',['../classMagellan_1_1DataModel_1_1RestLink.html#a948e4631bfe6b3cd9df42d7246feeb0f',1,'Magellan::DataModel::RestLink']]],
  ['addreference',['addReference',['../classMagellan_1_1ReferenceCountedObject.html#ac84e3af1a32ad1310224ae61ead59ffd',1,'Magellan::ReferenceCountedObject']]],
  ['address',['address',['../classMagellan_1_1DataModel_1_1NetworkAddress.html#a09715f771119596159309c1aaa6b8380',1,'Magellan::DataModel::NetworkAddress']]],
  ['appdiscoverer',['AppDiscoverer',['../classMagellan_1_1AppDiscoverer.html',1,'Magellan']]],
  ['avahidiscoverer',['AvahiDiscoverer',['../classMagellan_1_1AvahiDiscoverer.html',1,'Magellan']]]
];
