var searchData=
[
  ['magellan_5fnull_5ftoken',['MAGELLAN_NULL_TOKEN',['../MagellanConstants_8h.html#ada42189edae50bc83825ba9fd052c8f5',1,'MagellanConstants.h']]]
];
