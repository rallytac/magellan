var searchData=
[
  ['listener',['listener',['../classMagellan_1_1DataModel_1_1Ssdp.html#a90b309bd2a7918057f33e5a42319b1a1',1,'Magellan::DataModel::Ssdp']]],
  ['logurloperation',['logUrlOperation',['../classMagellan_1_1DataModel_1_1RestLink.html#af8829e73da38f4a0c88750bf82996107',1,'Magellan::DataModel::RestLink']]]
];
