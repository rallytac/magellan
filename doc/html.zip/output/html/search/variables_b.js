var searchData=
[
  ['name',['name',['../classMagellan_1_1DataModel_1_1Talkgroup.html#aa3d7d039ac160fcae5a28576eec4b95b',1,'Magellan::DataModel::Talkgroup']]],
  ['networkoptions',['networkOptions',['../classMagellan_1_1DataModel_1_1Talkgroup.html#ae29220caa0c3dd4da4946a192acb5f10',1,'Magellan::DataModel::Talkgroup']]],
  ['nohdrext',['noHdrExt',['../classMagellan_1_1DataModel_1_1TxAudio.html#ac8a6c9171a4b7d10dd73355a496ae235',1,'Magellan::DataModel::TxAudio']]]
];
