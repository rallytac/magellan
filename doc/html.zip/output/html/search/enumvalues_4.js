var searchData=
[
  ['warning',['warning',['../classMagellan_1_1ILogger.html#ab4fe76c1bd3523d49bb31b1a0d2d7bf1a7d4bf19a13825c09759c03066956bea2',1,'Magellan::ILogger']]]
];
