var searchData=
[
  ['appdiscoverer',['AppDiscoverer',['../classMagellan_1_1AppDiscoverer.html',1,'Magellan']]],
  ['avahidiscoverer',['AvahiDiscoverer',['../classMagellan_1_1AvahiDiscoverer.html',1,'Magellan']]]
];
