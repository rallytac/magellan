var searchData=
[
  ['i',['i',['../classMagellan_1_1ILogger.html#a149d7700621f6db7e81ac71fd8e5e762',1,'Magellan::ILogger::i()'],['../classMagellan_1_1SimpleLogger.html#a0bc5aea2c99683c47e8f51b5ca170367',1,'Magellan::SimpleLogger::i()']]],
  ['ilogger',['ILogger',['../classMagellan_1_1ILogger.html#a79b416c8c836c42095fb609ee23707fe',1,'Magellan::ILogger']]],
  ['issyslogenabled',['isSyslogEnabled',['../classMagellan_1_1ILogger.html#aa7e882de1da9ed85a1ca6e884afb3ffd',1,'Magellan::ILogger']]],
  ['isvalidlevel',['isValidLevel',['../classMagellan_1_1ILogger.html#adecb6fc28d0380bae1ec0d4d95ff8619',1,'Magellan::ILogger']]]
];
