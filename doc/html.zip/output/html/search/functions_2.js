var searchData=
[
  ['d',['d',['../classMagellan_1_1ILogger.html#a8275802194a542716607887736565346',1,'Magellan::ILogger::d()'],['../classMagellan_1_1SimpleLogger.html#a598e384734c0764ff2e245fa52b6dabb',1,'Magellan::SimpleLogger::d()']]],
  ['deletethis',['deleteThis',['../classMagellan_1_1AvahiDiscoverer.html#a8d9a92bea9557e71d8968f5a5c423ea0',1,'Magellan::AvahiDiscoverer::deleteThis()'],['../classMagellan_1_1BonjourDiscoverer.html#af24724cff7cefeddfefe96e5f693aec6',1,'Magellan::BonjourDiscoverer::deleteThis()'],['../classMagellan_1_1ReferenceCountedObject.html#ae068717aa387ec6549a25446663d5dc5',1,'Magellan::ReferenceCountedObject::deleteThis()'],['../classMagellan_1_1SsdpDiscoverer.html#a2b2c943888df41209420ebe6327899d3',1,'Magellan::SsdpDiscoverer::deleteThis()']]],
  ['disablesubmissions',['disableSubmissions',['../classMagellan_1_1WorkQueue.html#aa45b8d509072520030745539a4b87905',1,'Magellan::WorkQueue']]],
  ['discoverer',['Discoverer',['../classMagellan_1_1Discoverer.html#ad0470c623f9367d3c7bb56f77a7cf4a2',1,'Magellan::Discoverer']]]
];
