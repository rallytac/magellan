var searchData=
[
  ['_7ediscoverer',['~Discoverer',['../classMagellan_1_1Discoverer.html#ae0fb97460cbc04ea79c3f259a8723f89',1,'Magellan::Discoverer']]],
  ['_7eilogger',['~ILogger',['../classMagellan_1_1ILogger.html#a37a4796ba13bc83cda3a73a0617c2ec1',1,'Magellan::ILogger']]],
  ['_7emagellanobject',['~MagellanObject',['../classMagellan_1_1MagellanObject.html#af980f3dc0be5caa506af4773e01269d9',1,'Magellan::MagellanObject']]],
  ['_7ereferencecountedobject',['~ReferenceCountedObject',['../classMagellan_1_1ReferenceCountedObject.html#aa296ccb2fb92a03cb1bdbfca18e883d0',1,'Magellan::ReferenceCountedObject']]],
  ['_7esem',['~Sem',['../classMagellan_1_1Sem.html#a77e2159f3171e5065e28f4e4ca7ee301',1,'Magellan::Sem']]],
  ['_7esimplelogger',['~SimpleLogger',['../classMagellan_1_1SimpleLogger.html#a0cd3062b494dd122a8b3e6710b8e6569',1,'Magellan::SimpleLogger']]],
  ['_7eworkqueue',['~WorkQueue',['../classMagellan_1_1WorkQueue.html#a73b3f9efb049687599d1142c5cc804f5',1,'Magellan::WorkQueue']]]
];
