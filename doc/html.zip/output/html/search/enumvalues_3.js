var searchData=
[
  ['info',['info',['../classMagellan_1_1ILogger.html#ab4fe76c1bd3523d49bb31b1a0d2d7bf1a7e733c7725f9cc6ddc6550b9e4c7bcd9',1,'Magellan::ILogger']]]
];
