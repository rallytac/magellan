var searchData=
[
  ['addreference',['addReference',['../classMagellan_1_1ReferenceCountedObject.html#ac84e3af1a32ad1310224ae61ead59ffd',1,'Magellan::ReferenceCountedObject']]]
];
