var searchData=
[
  ['e',['e',['../classMagellan_1_1ILogger.html#af2e2f398fd07dbcfed675a8470bf4258',1,'Magellan::ILogger::e()'],['../classMagellan_1_1SimpleLogger.html#a4615bddfe0da674bef1a7578aac25b50',1,'Magellan::SimpleLogger::e()']]],
  ['enablesubmissions',['enableSubmissions',['../classMagellan_1_1WorkQueue.html#a8bb655d5e3b25b74e0e687d9456f3731',1,'Magellan::WorkQueue']]]
];
