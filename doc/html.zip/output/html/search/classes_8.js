var searchData=
[
  ['presence',['Presence',['../classMagellan_1_1DataModel_1_1Presence.html',1,'Magellan::DataModel']]]
];
