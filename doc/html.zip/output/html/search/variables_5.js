var searchData=
[
  ['fdx',['fdx',['../classMagellan_1_1DataModel_1_1TxAudio.html#a699c6bcc62401f4217cbdb54b022ad87',1,'Magellan::DataModel::TxAudio']]],
  ['forceonaudiotransmit',['forceOnAudioTransmit',['../classMagellan_1_1DataModel_1_1Presence.html#af3bd752ae8dac902c50b9a2fa30a126e',1,'Magellan::DataModel::Presence']]],
  ['format',['format',['../classMagellan_1_1DataModel_1_1Presence.html#a3fbe398c5210be43340a01386eb0ef63',1,'Magellan::DataModel::Presence']]],
  ['framingms',['framingMs',['../classMagellan_1_1DataModel_1_1TxAudio.html#a9c71e49103c585862f2271cb74aacee8',1,'Magellan::DataModel::TxAudio']]]
];
