var searchData=
[
  ['f',['f',['../classMagellan_1_1ILogger.html#ae59c21119204e1c4ed4a74aa2eb4cab9',1,'Magellan::ILogger::f()'],['../classMagellan_1_1SimpleLogger.html#a128681255bb3ce8644b87274c5b0510e',1,'Magellan::SimpleLogger::f()']]]
];
