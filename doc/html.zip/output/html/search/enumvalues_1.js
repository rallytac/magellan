var searchData=
[
  ['error',['error',['../classMagellan_1_1ILogger.html#ab4fe76c1bd3523d49bb31b1a0d2d7bf1ab2f4f80035d3ecacfc38370ba3bc8ef1',1,'Magellan::ILogger']]]
];
