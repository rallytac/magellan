var searchData=
[
  ['id',['id',['../classMagellan_1_1DataModel_1_1DiscoveredDevice.html#af67b4848d29d9cc8b4305436b5e3ade0',1,'Magellan::DataModel::DiscoveredDevice::id()'],['../classMagellan_1_1DataModel_1_1ThingInfo.html#a6f17e52daba0c49114d58c79c0568e1c',1,'Magellan::DataModel::ThingInfo::id()'],['../classMagellan_1_1DataModel_1_1Talkgroup.html#ad5033f8441acf69b79a3f9aae8822933',1,'Magellan::DataModel::Talkgroup::id()']]],
  ['initialheaderburst',['initialHeaderBurst',['../classMagellan_1_1DataModel_1_1TxAudio.html#ad32d663b509afeb2b9e30496e10cc80d',1,'Magellan::DataModel::TxAudio']]],
  ['intervalsecs',['intervalSecs',['../classMagellan_1_1DataModel_1_1Presence.html#af6f91474e27975aa055544b5f145f737',1,'Magellan::DataModel::Presence']]]
];
