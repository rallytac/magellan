var searchData=
[
  ['magellanconfiguration',['MagellanConfiguration',['../classMagellan_1_1DataModel_1_1MagellanConfiguration.html',1,'Magellan::DataModel']]],
  ['magellanobject',['MagellanObject',['../classMagellan_1_1MagellanObject.html',1,'Magellan']]],
  ['mdns',['Mdns',['../classMagellan_1_1DataModel_1_1Mdns.html',1,'Magellan::DataModel']]]
];
