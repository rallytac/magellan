var searchData=
[
  ['keyfile',['keyFile',['../classMagellan_1_1DataModel_1_1RestLink.html#a5c95de3319d37912bbaa35c4f98207d0',1,'Magellan::DataModel::RestLink']]],
  ['keypass',['keyPass',['../classMagellan_1_1DataModel_1_1RestLink.html#ad2dfa8825d5bda2075fe63e6fb852aa2',1,'Magellan::DataModel::RestLink']]]
];
