var searchData=
[
  ['port',['port',['../classMagellan_1_1DataModel_1_1NetworkAddress.html#a51e4c3d4ed4f42512aa4198473ecf330',1,'Magellan::DataModel::NetworkAddress']]],
  ['presence',['presence',['../classMagellan_1_1DataModel_1_1Talkgroup.html#a3ae67cffd04ff93a4f83777acfd16129',1,'Magellan::DataModel::Talkgroup']]],
  ['priority',['priority',['../classMagellan_1_1DataModel_1_1NetworkOptions.html#a29d91434ed8163be9cebb8d13b0a2066',1,'Magellan::DataModel::NetworkOptions']]]
];
