var classMagellan_1_1Core_1_1DeviceConfigurationDownloadCtx =
[
    [ "DeviceConfigurationDownloadCtx", "classMagellan_1_1Core_1_1DeviceConfigurationDownloadCtx.html#ab15a4a40974e03e08d21d65a1013b7e4", null ],
    [ "_dc", "classMagellan_1_1Core_1_1DeviceConfigurationDownloadCtx.html#a5faf2412271731f3aad64f98e4463b11", null ],
    [ "_ok", "classMagellan_1_1Core_1_1DeviceConfigurationDownloadCtx.html#a5e5891cef65645c1033ae79eb5338f3f", null ]
];