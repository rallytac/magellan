var classMagellan_1_1SsdpDiscoverer =
[
    [ "SsdpDiscoverer", "classMagellan_1_1SsdpDiscoverer.html#a7f04749dfa7dfac720a1ced58b4920a7", null ],
    [ "~SsdpDiscoverer", "classMagellan_1_1SsdpDiscoverer.html#a998d4a0624c9c1cbcad200aeaab821ef", null ],
    [ "configure", "classMagellan_1_1SsdpDiscoverer.html#a99e94f2547fb1580336c49a7f099af5b", null ],
    [ "deleteThis", "classMagellan_1_1SsdpDiscoverer.html#a2b2c943888df41209420ebe6327899d3", null ],
    [ "pause", "classMagellan_1_1SsdpDiscoverer.html#acba31a6f8f4bcf852b5c632174322b6c", null ],
    [ "resume", "classMagellan_1_1SsdpDiscoverer.html#abbcdd326dd5bef272db95f92c7659579", null ],
    [ "start", "classMagellan_1_1SsdpDiscoverer.html#a881e6025aedc1687344abcd520eca3b9", null ],
    [ "stop", "classMagellan_1_1SsdpDiscoverer.html#ac39e9c73792db39b955f35ef6a7fa3cd", null ]
];