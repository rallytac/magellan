var classMagellan_1_1DataModel_1_1JsonObjectBase =
[
    [ "JsonObjectBase", "classMagellan_1_1DataModel_1_1JsonObjectBase.html#a5929202df2f6a0049020bb5ef2c16661", null ],
    [ "~JsonObjectBase", "classMagellan_1_1DataModel_1_1JsonObjectBase.html#ae1ddcb3588b15e537fc399b567686a3b", null ],
    [ "clear", "classMagellan_1_1DataModel_1_1JsonObjectBase.html#a4538e9ed4e6fcd5d50c2d4178325bf0f", null ],
    [ "initForDocumenting", "classMagellan_1_1DataModel_1_1JsonObjectBase.html#a0f64d65b8ede7b10634ec1cee225fe70", null ],
    [ "setDefaultsIfNecessary", "classMagellan_1_1DataModel_1_1JsonObjectBase.html#a52c81e2af4a634daf2fd07802767442a", null ],
    [ "_documenting", "classMagellan_1_1DataModel_1_1JsonObjectBase.html#abb6d22f781ab927e2476407761592254", null ]
];