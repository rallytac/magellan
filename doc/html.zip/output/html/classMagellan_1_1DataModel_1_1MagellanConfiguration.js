var classMagellan_1_1DataModel_1_1MagellanConfiguration =
[
    [ "MagellanConfiguration", "classMagellan_1_1DataModel_1_1MagellanConfiguration.html#adb7c078b8feeacd0ea97322ce49d0f74", null ],
    [ "clear", "classMagellan_1_1DataModel_1_1MagellanConfiguration.html#a784ebfbb8c5ff8a5503a63600dfd156d", null ],
    [ "houseKeeperIntervalMs", "classMagellan_1_1DataModel_1_1MagellanConfiguration.html#a3e5735c41c179ed577e2532a5308769a", null ],
    [ "mdns", "classMagellan_1_1DataModel_1_1MagellanConfiguration.html#aec3d1126eba089489432c4220ea56d14", null ],
    [ "restLink", "classMagellan_1_1DataModel_1_1MagellanConfiguration.html#a1eb3d330c50db9e491586a56cfc8c08e", null ],
    [ "ssdp", "classMagellan_1_1DataModel_1_1MagellanConfiguration.html#ae09f3434929b8bac91db8dca704965f8", null ]
];