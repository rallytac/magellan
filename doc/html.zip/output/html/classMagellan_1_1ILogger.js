var classMagellan_1_1ILogger =
[
    [ "Level", "classMagellan_1_1ILogger.html#ab4fe76c1bd3523d49bb31b1a0d2d7bf1", [
      [ "fatal", "classMagellan_1_1ILogger.html#ab4fe76c1bd3523d49bb31b1a0d2d7bf1a8b049bc37b7e6f19a733215710bce1f1", null ],
      [ "error", "classMagellan_1_1ILogger.html#ab4fe76c1bd3523d49bb31b1a0d2d7bf1ab2f4f80035d3ecacfc38370ba3bc8ef1", null ],
      [ "warning", "classMagellan_1_1ILogger.html#ab4fe76c1bd3523d49bb31b1a0d2d7bf1a7d4bf19a13825c09759c03066956bea2", null ],
      [ "info", "classMagellan_1_1ILogger.html#ab4fe76c1bd3523d49bb31b1a0d2d7bf1a7e733c7725f9cc6ddc6550b9e4c7bcd9", null ],
      [ "debug", "classMagellan_1_1ILogger.html#ab4fe76c1bd3523d49bb31b1a0d2d7bf1ac2181dbfd3a5b2292d64a13ebb50cba7", null ]
    ] ],
    [ "ILogger", "classMagellan_1_1ILogger.html#a79b416c8c836c42095fb609ee23707fe", null ],
    [ "~ILogger", "classMagellan_1_1ILogger.html#a37a4796ba13bc83cda3a73a0617c2ec1", null ],
    [ "d", "classMagellan_1_1ILogger.html#a8275802194a542716607887736565346", null ],
    [ "e", "classMagellan_1_1ILogger.html#af2e2f398fd07dbcfed675a8470bf4258", null ],
    [ "f", "classMagellan_1_1ILogger.html#ae59c21119204e1c4ed4a74aa2eb4cab9", null ],
    [ "getMaxLevel", "classMagellan_1_1ILogger.html#ad5def5b76223847ea986fbd0ca936a7e", null ],
    [ "i", "classMagellan_1_1ILogger.html#a149d7700621f6db7e81ac71fd8e5e762", null ],
    [ "isSyslogEnabled", "classMagellan_1_1ILogger.html#aa7e882de1da9ed85a1ca6e884afb3ffd", null ],
    [ "isValidLevel", "classMagellan_1_1ILogger.html#adecb6fc28d0380bae1ec0d4d95ff8619", null ],
    [ "setMaxLevel", "classMagellan_1_1ILogger.html#ae4ce0a4f8f4d8b09210561ca9b9e312d", null ],
    [ "setSyslogEnabled", "classMagellan_1_1ILogger.html#a0b5ed1109bd359dfab6ec07829ded0e7", null ],
    [ "w", "classMagellan_1_1ILogger.html#a5faeeaed82ae2f69994133a02f71e284", null ],
    [ "_enableSyslog", "classMagellan_1_1ILogger.html#afe3e37077581e1979b7ce62e668844b1", null ],
    [ "_maxLevel", "classMagellan_1_1ILogger.html#aaf6219ebb701fabf3129f054eb740672", null ]
];