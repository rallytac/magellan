var classMagellan_1_1WorkQueue =
[
    [ "WorkQueue", "classMagellan_1_1WorkQueue.html#a624b8abad8c8fd31e4a84e2de3f514f9", null ],
    [ "~WorkQueue", "classMagellan_1_1WorkQueue.html#a73b3f9efb049687599d1142c5cc804f5", null ],
    [ "disableSubmissions", "classMagellan_1_1WorkQueue.html#aa45b8d509072520030745539a4b87905", null ],
    [ "enableSubmissions", "classMagellan_1_1WorkQueue.html#a8bb655d5e3b25b74e0e687d9456f3731", null ],
    [ "getMaxDepth", "classMagellan_1_1WorkQueue.html#a370f05c3e00e52ed64ba1e37ff1479e0", null ],
    [ "reset", "classMagellan_1_1WorkQueue.html#a8793d4544077b8a4226756b704b56a65", null ],
    [ "restart", "classMagellan_1_1WorkQueue.html#af8e9e43a44d554e247cc5fdde55ed272", null ],
    [ "setMaxDepth", "classMagellan_1_1WorkQueue.html#a6c8e6aca8b2d25fcc40f01fbd7e2bab1", null ],
    [ "start", "classMagellan_1_1WorkQueue.html#ab8b3faa13455d0bd1c5b190b3fc35b0d", null ],
    [ "stop", "classMagellan_1_1WorkQueue.html#a1f9c96a93bc99102854aa652ffdbc00c", null ],
    [ "submit", "classMagellan_1_1WorkQueue.html#a439d7e493d81db8d8ec3f86154ce9c1e", null ],
    [ "submitAndWait", "classMagellan_1_1WorkQueue.html#ab1988ab3d969721ab08c0c05b99bb4ee", null ],
    [ "DEFAULT_MAX_DEPTH", "classMagellan_1_1WorkQueue.html#a06ab8638a06aeaef69850cb5c260700c", null ]
];