var classMagellan_1_1DataModel_1_1DeviceConfiguration =
[
    [ "DeviceConfiguration", "classMagellan_1_1DataModel_1_1DeviceConfiguration.html#a2875d30253dd880f652173ef53759fd9", null ],
    [ "clear", "classMagellan_1_1DataModel_1_1DeviceConfiguration.html#ae11d34194644e4e7877f9e468006b1ab", null ],
    [ "dateTimeStamp", "classMagellan_1_1DataModel_1_1DeviceConfiguration.html#a1eb7140d14b98d38b7574d2ad634fe36", null ],
    [ "discovererKey", "classMagellan_1_1DataModel_1_1DeviceConfiguration.html#a17befd60fd3a15cac79d523e8dbfc15c", null ],
    [ "talkgroups", "classMagellan_1_1DataModel_1_1DeviceConfiguration.html#afc96e2b6bcb2c241ef9e66b756fdf9d2", null ],
    [ "thingInfo", "classMagellan_1_1DataModel_1_1DeviceConfiguration.html#ade4a3e22c2a6e11efcf45b702e005f29", null ],
    [ "version", "classMagellan_1_1DataModel_1_1DeviceConfiguration.html#a908b00ced52aa68b98f6ecce37354264", null ]
];