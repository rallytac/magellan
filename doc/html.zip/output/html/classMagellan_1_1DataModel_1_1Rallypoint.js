var classMagellan_1_1DataModel_1_1Rallypoint =
[
    [ "Rallypoint", "classMagellan_1_1DataModel_1_1Rallypoint.html#a0c17d26fe11130e6abd5192c26c34b72", null ],
    [ "clear", "classMagellan_1_1DataModel_1_1Rallypoint.html#aa1d491ea634c1840d67c86ea04e1c402", null ],
    [ "matches", "classMagellan_1_1DataModel_1_1Rallypoint.html#aee439fa686336f18dd10d37041eb2729", null ],
    [ "host", "classMagellan_1_1DataModel_1_1Rallypoint.html#a61b14bf17f2f92d50ed9debd1355c598", null ]
];