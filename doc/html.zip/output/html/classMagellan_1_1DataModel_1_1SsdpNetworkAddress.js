var classMagellan_1_1DataModel_1_1SsdpNetworkAddress =
[
    [ "SsdpNetworkAddress", "classMagellan_1_1DataModel_1_1SsdpNetworkAddress.html#a149f9e1aac00270958c1b9e775ddf539", null ],
    [ "setDefaultsIfNecessary", "classMagellan_1_1DataModel_1_1SsdpNetworkAddress.html#af329e00f49dd1fe8b68560872bedbf4e", null ]
];