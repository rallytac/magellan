var group__resultCodes =
[
    [ "MAGELLAN_RESULT_ALREADY_INITIALIZED", "group__resultCodes.html#gacc8d9e9e0224f938c3662d002f6ed1a1", null ],
    [ "MAGELLAN_RESULT_GENERAL_FAILURE", "group__resultCodes.html#ga31a041e6577153417d99ade7de467f19", null ],
    [ "MAGELLAN_RESULT_INVALID_PARAMETERS", "group__resultCodes.html#gadf874eccfba2c44a873e73827a8a74c0", null ],
    [ "MAGELLAN_RESULT_NOT_INITIALIZED", "group__resultCodes.html#ga78aecabc00b8a6df30be79157c9b7dec", null ],
    [ "MAGELLAN_RESULT_OK", "group__resultCodes.html#gaeba1be517178dbaeb5038c1579dc8d2f", null ]
];