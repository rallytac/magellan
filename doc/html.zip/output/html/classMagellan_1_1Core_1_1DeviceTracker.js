var classMagellan_1_1Core_1_1DeviceTracker =
[
    [ "ProcessingState_t", "classMagellan_1_1Core_1_1DeviceTracker.html#ac398e75f5bc520102a41003edc5e7c77", [
      [ "psNone", "classMagellan_1_1Core_1_1DeviceTracker.html#ac398e75f5bc520102a41003edc5e7c77a08297097de73d966eed61a122924b295", null ],
      [ "psPending", "classMagellan_1_1Core_1_1DeviceTracker.html#ac398e75f5bc520102a41003edc5e7c77adcbd08507941c1198fbdc42680e26086", null ],
      [ "psInProgress", "classMagellan_1_1Core_1_1DeviceTracker.html#ac398e75f5bc520102a41003edc5e7c77a462d53b8f77dcfac97d1861cc3361e18", null ],
      [ "psComplete", "classMagellan_1_1Core_1_1DeviceTracker.html#ac398e75f5bc520102a41003edc5e7c77ad79c0c026167a38f1cec01b9c974bc41", null ]
    ] ],
    [ "DeviceTracker", "classMagellan_1_1Core_1_1DeviceTracker.html#a613c734367bb5eb1c121d2221bd673c3", null ],
    [ "~DeviceTracker", "classMagellan_1_1Core_1_1DeviceTracker.html#afe140005655155012e4b72db041b4d73", null ],
    [ "_cfg", "classMagellan_1_1Core_1_1DeviceTracker.html#ac36dae8ad36df93a7c6d546c78e52628", null ],
    [ "_consecutiveErrors", "classMagellan_1_1Core_1_1DeviceTracker.html#aafbfa122d6aebde1f05cb688d132bac1", null ],
    [ "_key", "classMagellan_1_1Core_1_1DeviceTracker.html#a6896b69a54a4834d6aa0f2e348614097", null ],
    [ "_nextCheckTs", "classMagellan_1_1Core_1_1DeviceTracker.html#a36dd070321f68ef64b61ba1e9ccdf2f9", null ],
    [ "_ps", "classMagellan_1_1Core_1_1DeviceTracker.html#ad518f947637923dc91cd788c0c6d4107", null ],
    [ "_url", "classMagellan_1_1Core_1_1DeviceTracker.html#aaa76a79c5ef3b34673ebaedf6d5244d2", null ]
];