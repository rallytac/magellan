var classMagellan_1_1ReferenceCountedObject =
[
    [ "ReferenceCountedObject", "classMagellan_1_1ReferenceCountedObject.html#a6ec00c928c1efe12eda9cf4c546fc0a0", null ],
    [ "~ReferenceCountedObject", "classMagellan_1_1ReferenceCountedObject.html#aa296ccb2fb92a03cb1bdbfca18e883d0", null ],
    [ "addReference", "classMagellan_1_1ReferenceCountedObject.html#ac84e3af1a32ad1310224ae61ead59ffd", null ],
    [ "deleteThis", "classMagellan_1_1ReferenceCountedObject.html#ae068717aa387ec6549a25446663d5dc5", null ],
    [ "getRefCount", "classMagellan_1_1ReferenceCountedObject.html#a0eed127c20c3735150995e33f5e81a09", null ],
    [ "releaseReference", "classMagellan_1_1ReferenceCountedObject.html#a882bca099fea6d62321a51982f623667", null ]
];