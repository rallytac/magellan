var classMagellan_1_1TimerManager =
[
    [ "CALLBACK_FN", "classMagellan_1_1TimerManager.html#ab3d96499d752dcf7cb10ff24bca3ccee", null ],
    [ "TimerManager", "classMagellan_1_1TimerManager.html#adadaf0e1bad8a81b08ee9b5facad1266", null ],
    [ "~TimerManager", "classMagellan_1_1TimerManager.html#ad02918a596e666e20fd682f11b1e109c", null ],
    [ "cancelTimer", "classMagellan_1_1TimerManager.html#a43bea7158701e721012dd44d753fe80e", null ],
    [ "restartTimer", "classMagellan_1_1TimerManager.html#a273e5c329cb0ab6487d0e562a02f3ceb", null ],
    [ "setTimer", "classMagellan_1_1TimerManager.html#a3e50d22d8097ca6192851f94bc01d324", null ],
    [ "start", "classMagellan_1_1TimerManager.html#ac748cdb329628b8811634146d2f09f0f", null ],
    [ "stop", "classMagellan_1_1TimerManager.html#abee3cb5c4a5b85ae91397016a90109ba", null ]
];