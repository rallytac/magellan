var classMagellan_1_1DataModel_1_1ThingInfo =
[
    [ "ThingInfo", "classMagellan_1_1DataModel_1_1ThingInfo.html#a4e78c7c0c0e6a1c3eec26fc24b76a19f", null ],
    [ "clear", "classMagellan_1_1DataModel_1_1ThingInfo.html#afb0249005ad5176aaaabae6a9b84c44a", null ],
    [ "capabilities", "classMagellan_1_1DataModel_1_1ThingInfo.html#a4627da3ba288feddf2043cf71c9042ef", null ],
    [ "id", "classMagellan_1_1DataModel_1_1ThingInfo.html#a6f17e52daba0c49114d58c79c0568e1c", null ],
    [ "manufacturer", "classMagellan_1_1DataModel_1_1ThingInfo.html#ad4a8bcb98306160dbd45bd1f7b7afaa3", null ],
    [ "type", "classMagellan_1_1DataModel_1_1ThingInfo.html#ab3c772b5720938bfb713c695db17f883", null ]
];