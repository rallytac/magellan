var classMagellan_1_1DataModel_1_1Ssdp =
[
    [ "Ssdp", "classMagellan_1_1DataModel_1_1Ssdp.html#a465efa62de5b70c61d716121657d14e9", null ],
    [ "clear", "classMagellan_1_1DataModel_1_1Ssdp.html#a33d6f75df0756674f4c2b35de6e3864d", null ],
    [ "setDefaultsIfNecessary", "classMagellan_1_1DataModel_1_1Ssdp.html#a0a58abe38201bb60c30de4c842d976f9", null ],
    [ "listener", "classMagellan_1_1DataModel_1_1Ssdp.html#a90b309bd2a7918057f33e5a42319b1a1", null ],
    [ "maxReconnectMs", "classMagellan_1_1DataModel_1_1Ssdp.html#aa43bc7e78d5f9394b9c49a2b7a50e70c", null ],
    [ "mx", "classMagellan_1_1DataModel_1_1Ssdp.html#a5b8b38a7448ea0f752ac5ca7d4442169", null ],
    [ "st", "classMagellan_1_1DataModel_1_1Ssdp.html#a17bf71ad7bdb521cf98a66434e2f4fd0", null ],
    [ "staleNeighorCheckIntervalMs", "classMagellan_1_1DataModel_1_1Ssdp.html#ad33cca03218574dc6128aee75b4416a0", null ],
    [ "userAgent", "classMagellan_1_1DataModel_1_1Ssdp.html#a65b0674294286f3d79956524486ea74c", null ]
];