var hierarchy =
[
    [ "Magellan::Core::DeviceConfigurationDownloadCtx", "classMagellan_1_1Core_1_1DeviceConfigurationDownloadCtx.html", null ],
    [ "Magellan::Core::DeviceTracker", "classMagellan_1_1Core_1_1DeviceTracker.html", null ],
    [ "Magellan::ILogger", "classMagellan_1_1ILogger.html", [
      [ "Magellan::SimpleLogger", "classMagellan_1_1SimpleLogger.html", null ]
    ] ],
    [ "Magellan::DataModel::JsonObjectBase", "classMagellan_1_1DataModel_1_1JsonObjectBase.html", [
      [ "Magellan::DataModel::DeviceConfiguration", "classMagellan_1_1DataModel_1_1DeviceConfiguration.html", null ],
      [ "Magellan::DataModel::DiscoveredDevice", "classMagellan_1_1DataModel_1_1DiscoveredDevice.html", null ],
      [ "Magellan::DataModel::MagellanConfiguration", "classMagellan_1_1DataModel_1_1MagellanConfiguration.html", null ],
      [ "Magellan::DataModel::Mdns", "classMagellan_1_1DataModel_1_1Mdns.html", null ],
      [ "Magellan::DataModel::NetworkAddress", "classMagellan_1_1DataModel_1_1NetworkAddress.html", [
        [ "Magellan::DataModel::SsdpNetworkAddress", "classMagellan_1_1DataModel_1_1SsdpNetworkAddress.html", null ]
      ] ],
      [ "Magellan::DataModel::NetworkOptions", "classMagellan_1_1DataModel_1_1NetworkOptions.html", null ],
      [ "Magellan::DataModel::Presence", "classMagellan_1_1DataModel_1_1Presence.html", null ],
      [ "Magellan::DataModel::Rallypoint", "classMagellan_1_1DataModel_1_1Rallypoint.html", null ],
      [ "Magellan::DataModel::RestLink", "classMagellan_1_1DataModel_1_1RestLink.html", null ],
      [ "Magellan::DataModel::Ssdp", "classMagellan_1_1DataModel_1_1Ssdp.html", null ],
      [ "Magellan::DataModel::Talkgroup", "classMagellan_1_1DataModel_1_1Talkgroup.html", null ],
      [ "Magellan::DataModel::TalkgroupSecurity", "classMagellan_1_1DataModel_1_1TalkgroupSecurity.html", null ],
      [ "Magellan::DataModel::ThingInfo", "classMagellan_1_1DataModel_1_1ThingInfo.html", null ],
      [ "Magellan::DataModel::TxAudio", "classMagellan_1_1DataModel_1_1TxAudio.html", null ]
    ] ],
    [ "Magellan::lssdp_packet", "structMagellan_1_1lssdp__packet.html", null ],
    [ "Magellan::ReferenceCountedObject", "classMagellan_1_1ReferenceCountedObject.html", [
      [ "Magellan::MagellanObject", "classMagellan_1_1MagellanObject.html", [
        [ "Magellan::Discoverer", "classMagellan_1_1Discoverer.html", [
          [ "Magellan::AppDiscoverer", "classMagellan_1_1AppDiscoverer.html", null ],
          [ "Magellan::AvahiDiscoverer", "classMagellan_1_1AvahiDiscoverer.html", null ],
          [ "Magellan::BonjourDiscoverer", "classMagellan_1_1BonjourDiscoverer.html", null ],
          [ "Magellan::SsdpDiscoverer", "classMagellan_1_1SsdpDiscoverer.html", null ]
        ] ]
      ] ]
    ] ],
    [ "Magellan::Sem", "classMagellan_1_1Sem.html", null ],
    [ "Magellan::TimerManager", "classMagellan_1_1TimerManager.html", null ],
    [ "Magellan::WorkQueue", "classMagellan_1_1WorkQueue.html", null ]
];