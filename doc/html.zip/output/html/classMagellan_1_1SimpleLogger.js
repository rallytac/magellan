var classMagellan_1_1SimpleLogger =
[
    [ "SimpleLogger", "classMagellan_1_1SimpleLogger.html#a55bcad261a085141da58f9d271f44ad7", null ],
    [ "~SimpleLogger", "classMagellan_1_1SimpleLogger.html#a0cd3062b494dd122a8b3e6710b8e6569", null ],
    [ "d", "classMagellan_1_1SimpleLogger.html#a598e384734c0764ff2e245fa52b6dabb", null ],
    [ "e", "classMagellan_1_1SimpleLogger.html#a4615bddfe0da674bef1a7578aac25b50", null ],
    [ "f", "classMagellan_1_1SimpleLogger.html#a128681255bb3ce8644b87274c5b0510e", null ],
    [ "i", "classMagellan_1_1SimpleLogger.html#a0bc5aea2c99683c47e8f51b5ca170367", null ],
    [ "setOutputHook", "classMagellan_1_1SimpleLogger.html#a4842fb502e717358c9acd67822e118d3", null ],
    [ "w", "classMagellan_1_1SimpleLogger.html#aef26277fdd531ba40dceac60070ad13a", null ]
];