var classMagellan_1_1AvahiDiscoverer =
[
    [ "AvahiDiscoverer", "classMagellan_1_1AvahiDiscoverer.html#a202d04d04cfa70b5a3336945430e2b31", null ],
    [ "~AvahiDiscoverer", "classMagellan_1_1AvahiDiscoverer.html#ae6d11cb33c10e794b3bfff8f3c55b081", null ],
    [ "configure", "classMagellan_1_1AvahiDiscoverer.html#ac70b232c04590d6171ea6bca713f5695", null ],
    [ "deleteThis", "classMagellan_1_1AvahiDiscoverer.html#a8d9a92bea9557e71d8968f5a5c423ea0", null ],
    [ "pause", "classMagellan_1_1AvahiDiscoverer.html#a2b05c65a3b57e7e78681c244030b5113", null ],
    [ "resume", "classMagellan_1_1AvahiDiscoverer.html#a9453f717ea75f328330b5c28fb467aaa", null ],
    [ "start", "classMagellan_1_1AvahiDiscoverer.html#a04a7e7515fbed735fa0f0a1fb90a73fb", null ],
    [ "stop", "classMagellan_1_1AvahiDiscoverer.html#adb5e31eff58497a506d3f828e9282dc8", null ]
];